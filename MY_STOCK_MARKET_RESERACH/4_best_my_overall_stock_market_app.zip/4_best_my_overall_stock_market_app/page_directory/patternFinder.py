import yfinance as yf
import pandas as pd
import streamlit as st
import talib
import pandas_ta as ta

st.set_page_config(
    page_title = 'Pattern Watcher',
    layout = 'wide'
)

patterns_to_watch = {
    'CDLSHOOTINGSTAR':'Shooting Star',
    'CDLHAMMER':'Hammer',
    'CDLHANGINGMAN':'Hanging Man',
    'CDLLONGLEGGEDDOJI':'Long Legged Doji',
    'CDLDOJI':'Doji',
    'CDLDOJISTAR':'Doji Star',
    'CDLDRAGONFLYDOJI':'Dragonfly Doji',
    'CDLENGULFING':'Engulfing Pattern',
    'CDLEVENINGDOJISTAR':'Evening Doji Star',
    'CDLEVENINGSTAR':'Evening Star',
    'CDLGRAVESTONEDOJI':'Gravestone Doji',
    'CDLLONGLEGGEDDOJI':'Long Legged Doji',
    'CDLSPINNINGTOP':'Spinning Top'
}

def getDifferentChartInterval(ticker_name, p , i):
    arr_df = []
    df = yf.download(tickers = ticker_name, period = p, interval = i, auto_adjust = True, prepost = True).reset_index()
    for fn in patterns_to_watch.keys():
        pattern_function = getattr(talib, fn)
        results = pattern_function(df['Open'], df['High'], df['Low'], df['Close'])
        df[fn] = results
        df_to_save = df[((df[fn] == 100) | (df[fn] == -100))]
        if not df_to_save.empty:
            df_to = df_to_save[['Datetime', fn]]
            df_to['Datetime'] = pd.to_datetime(df_to['Datetime']).dt.strftime('%d-%m | %I:%M %p')
            obj = {}
            obj['df'] = df_to
            obj['pName'] = patterns_to_watch.get(fn)
            arr_df.append(obj)
    return arr_df

col1, col2,col3 = st.columns(3)

with col1:
    selected_ticker = st.selectbox(
        "Ticker", 
        ("^NSEI", "ACC.NS","INFY.NS","TCS.NS", "IRCTC.NS")
    )

with col2:
    selected_Period = st.selectbox(
        "Period",
        ("1d", "5d", "20d", "max")
    )
    
with col3:
    selected_interval = st.selectbox(
        "Interval",
        ("1m", "15m", "30m", "1d")
    )  

if selected_interval != None and selected_Period != None and selected_ticker != None: 
    arr_df = getDifferentChartInterval(selected_ticker,  selected_Period, selected_interval)
    
    cols_arr = []

    numberOfDfPerRow = 4
    rows = round(len(arr_df)/numberOfDfPerRow)
    print("rows: " + str(rows))
    print("length of arr_df : " +str(len(arr_df)))
    for r in range(0,rows+1):
        loop_over_list = arr_df[r*numberOfDfPerRow : r*numberOfDfPerRow + numberOfDfPerRow]
        if len(loop_over_list) > 0:
            row_columns = st.columns(len(loop_over_list))
            for index,col in enumerate(row_columns):
                with col:
                    st.markdown("### {}".format(loop_over_list[index]['pName']))
                    st.table(loop_over_list[index]['df'])
    
