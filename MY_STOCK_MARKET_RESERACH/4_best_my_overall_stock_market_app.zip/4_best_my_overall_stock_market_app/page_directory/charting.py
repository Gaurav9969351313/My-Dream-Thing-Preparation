from time import sleep
import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf
import talib
import pandas_ta as ta
import mplfinance as mpf
import matplotlib.pyplot as plt
from datetime import timedelta, date
from tradingview_ta import TA_Handler, Interval, Exchange
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(
    page_title = 'Charting By TimeFrame',
    layout = 'wide'
)

pd.set_option('display.max_colwidth', None)


def technical_indicators_df(daily_data):
    o = daily_data['Open'].values
    c = daily_data['Close'].values
    h = daily_data['High'].values
    l = daily_data['Low'].values
    v = daily_data['Volume'].astype(float).values

    ta_res = pd.DataFrame()
    
    # ta_res['SUPERTl_7_3.0'] = daily_data.ta.supertrend(high=daily_data['High'],low=daily_data['Low'],close=daily_data['Close'],period = 7,multiplier= 3)['SUPERTl_7_3.0']
    # ta_res['SUPERTs_7_3.0'] = daily_data.ta.supertrend(high=daily_data['High'],low=daily_data['Low'],close=daily_data['Close'],period = 7,multiplier= 3)['SUPERTs_7_3.0']
    
    ta_res['MA5'] = talib.MA(c, timeperiod=5) 
    
    ta_res['MACD'] = talib.MACD(c, fastperiod=12, slowperiod=26, signalperiod=9)[0]
    ta_res['MACDS'] = talib.MACD(c, fastperiod=12, slowperiod=26, signalperiod=9)[1]
    ta_res['MACDH'] = talib.MACD(c, fastperiod=12, slowperiod=26, signalperiod=9)[2]
    
    ta_res['RSI'] = talib.RSI(c, timeperiod=14)
    
    ta_res['obv'] = talib.OBV(c, v)

    slowk, slowd = talib.STOCH(h,l,c, 5, 3, 0, 3, 0)
    ta_res['STOCH_K'] = slowk
    ta_res['STOCH_D'] = slowd
    
    # DX: Directional Movement Index
    ta_res['DMI'] = talib.DX(h, l, c, timeperiod=14)
    
    ta_res['BBANDS_U'] = talib.BBANDS(c, timeperiod=5, nbdevup=2, nbdevdn=2, matype=0)[0]
    ta_res['BBANDS_M'] = talib.BBANDS(c, timeperiod=5, nbdevup=2, nbdevdn=2, matype=0)[1] 
    ta_res['BBANDS_L'] = talib.BBANDS(c, timeperiod=5, nbdevup=2, nbdevdn=2, matype=0)[2] 
    
    ta_res['CCI'] = talib.CCI(h,l,c, timeperiod=10)
    
    ta_res['MA10'] = talib.MA(c, timeperiod=10)
    ta_res['MA20'] = talib.MA(c, timeperiod=20)
    ta_res['MA60'] = talib.MA(c, timeperiod=60)
    ta_res['MA120'] = talib.MA(c, timeperiod=120)
    
    ta_res['VMA5'] = talib.MA(v, timeperiod=5) 
    ta_res['MA10'] = talib.MA(v, timeperiod=10)
    ta_res['MA20'] = talib.MA(v, timeperiod=20)
    ta_res['ADX'] = talib.ADX(h, l, c, timeperiod=14)
    ta_res['ADXR'] = talib.ADXR(h, l, c, timeperiod=14) 
    
    ta_res['AD'] = talib.AD(h, l, c, v)
    ta_res['ATR'] = talib.ATR(h, l, c, timeperiod=14) 
    ta_res['HT_DC'] = talib.HT_DCPERIOD(c)
    ta_res["High/Open"] = h / o
    ta_res["Low/Open"] = l / o
    ta_res["Close/Open"] = c / o
    
    ta_res["adx_a"] = talib.ADX(h,l,c, timeperiod=6)
    ta_res["adx_plus_di"] = talib.PLUS_DI(h,l,c, timeperiod=6)
    ta_res["adx_minus_di"] = talib.MINUS_DI(h,l,c, timeperiod=6)
    
    ta_res["ema5"] = talib.EMA(c, 5)
    
    ta_res['Open'] = o
    ta_res['High'] = h
    ta_res['Low'] = l
    ta_res['Close'] = c
    ta_res['Volume'] = v
    ta_res['Datetime'] = daily_data['Datetime']

    return ta_res

def getSeriesOfSameNumber(number, limit):
    list80 = []
    for i in range(0,limit):
        list80.append(number)
    series = pd.Series(list80)
    return series.values

def plotYahooAnalysisUsingMPL(dff):
    exp12     = dff['Close'].ewm(span=12, adjust=False).mean()
    exp26     = dff['Close'].ewm(span=26, adjust=False).mean()
    macd      = exp12 - exp26
    signal    = macd.ewm(span=9, adjust=False).mean()
    histogram = macd - signal

    fb_green = dict(y1=macd.values,y2=signal.values,where=signal<macd,color="#93c47d",alpha=0.6,interpolate=True)
    fb_red   = dict(y1=macd.values,y2=signal.values,where=signal>macd,color="#e06666",alpha=0.6,interpolate=True)
    fb_green['panel'] = 1
    fb_red['panel'] = 1
    fb = [fb_green,fb_red]
    plots = [
        mpf.make_addplot((dff['BBANDS_L']), color='#606060', panel=0, ylabel='BBL', secondary_y=False),
        mpf.make_addplot((dff['BBANDS_U']), color='#606060', panel=0, ylabel='BBU', secondary_y=False),
        
        mpf.make_addplot((dff['SUPERTs_7_3.0']), color='#CC3333', panel=0, ylabel='supertrend'),
        mpf.make_addplot((dff['SUPERTl_7_3.0']), color='#51A944', panel=0, ylabel='supertrend'),
        
        mpf.make_addplot(dff['RSI'],panel=2, color='black',ylim=(10,90),secondary_y=False),    
        mpf.make_addplot(getSeriesOfSameNumber(60,100),panel=2,color='r',secondary_y=False, title="RSI"),
        mpf.make_addplot(getSeriesOfSameNumber(40,100),panel=2,color='g',secondary_y=False), 
    
        mpf.make_addplot(histogram,type='bar',width=0.7,panel=3, color='dimgray',alpha=1,secondary_y=True),
        mpf.make_addplot(macd,panel=3,color='#51A944',secondary_y=False, title="MACD"),
        mpf.make_addplot(signal,panel=3,color='#CC3333',secondary_y=False),
        
        mpf.make_addplot((dff['STOCH_K']), color='#F39C12', panel=4, ylabel='k', secondary_y=False, title="Stoch"),
        mpf.make_addplot((dff['STOCH_D']), color='#3780BF', panel=4, ylabel='d', secondary_y=False),
        mpf.make_addplot(getSeriesOfSameNumber(80,100),panel=4,color='r',secondary_y=False),
        mpf.make_addplot(getSeriesOfSameNumber(20,100),panel=4,color='g',secondary_y=False)
    ]

    # addplot=plots
    fig, ax = mpf.plot(dff, 
                       style='yahoo', 
                       type='candle',
                       show_nontrading=False, 
                       mav=(5,20), 
                       volume=True,
                    #    addplot=plots, 
                       figsize=(15,10), 
                    #    figscale=1.5,
                    #    figratio=(6,5),
                       returnfig=True)

    st.pyplot(fig)

# https://stackoverflow.com/questions/16181121/a-very-simple-multithreading-parallel-url-fetching-without-queue
def getDifferentChartInterval(ticker_name, p , i, index_to_set):
    df_d = yf.download(tickers = ticker_name, period = p, interval = i, auto_adjust = True, prepost = True).reset_index()
    # df_d.index = pd.to_datetime(df_d[index_to_set])
    dff = technical_indicators_df(df_d)
    return dff

# https://github.com/tedtran6/Moving-Average-Chart-Plotly/blob/master/Moving%20Average%20Chart%20Plotly.ipynb
def plotYahooAnalysisUsingPlotly(df):
    
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True) # , vertical_spacing=0.02
    fig.add_trace(go.Candlestick(x = df['Datetime'], open = df['Open'], low = df['Low'], high = df['High'], close = df['Close'], increasing_line_color = 'green', decreasing_line_color = 'red')
            , row=1
            , col=1)

    fig.add_trace(go.Bar(x=df['Datetime'], y=df['Volume']), row=2, col=1)
    fig.update_layout(title = 'Interactive CandleStick & Volume Chart'
            , yaxis1_title = 'Stock Price (INR)'
            , yaxis2_title = 'Volume (M)'
            , xaxis2_title = 'Time'
            , width=700
            , height=700
            , xaxis1_rangeslider_visible = False
            , xaxis2_rangeslider_visible = False)
    
    # fig.add_trace(go.Scatter(name = "MA5", x = df['Datetime'], y = df['MA5'], line = dict(color = "#17BECF"), opacity = 0.6))
    # fig.add_trace(go.Scatter(name = "MA20", x = df['Datetime'], y = df['MA20'], line = dict(color = "#17BECF"), opacity = 0.6))

    # fig.append_trace(go.Scatter(x = df['Datetime'], y = df['RSI'], name = "RSI", marker = dict(color = '#A569BD')), row = 3, col = 1)
    # fig.add_shape(type = 'line', x0 = df['Datetime'].min(), x1 = df['Datetime'].max(), y0 = 40, y1 = 40, line = dict(color = '#008000', width = 1), row = 3, col = 1)
    # fig.add_shape(type = 'line', x0 = df['Datetime'].min(), x1 = df['Datetime'].max(), y0 = 60, y1 = 60, line = dict(color = '#FF0000', width = 1), row = 3, col = 1)

    # # STOCH
    # fig.append_trace(go.Scatter(x = df['Datetime'], y = df['STOCH_K'], name = "Stochastic K", marker = dict(color = '#F39C12')), row = 4, col = 1)
    # fig.append_trace(go.Scatter(x = df['Datetime'], y = df['STOCH_D'], name = "Stochastic D", marker = dict(color = '#3780BF')), row = 4, col = 1)
    # fig.add_shape(type = 'line', x0 = df['Datetime'].min(), x1 = df['Datetime'].max(), y0 = 20, y1 = 20, line = dict(color = '#008000', width = 1), row = 4, col = 1)
    # fig.add_shape(type = 'line', x0 = df['Datetime'].min(), x1 = df['Datetime'].max(), y0 = 80, y1 = 80, line = dict(color = '#FF0000', width = 1), row = 4, col = 1)

    # # MACD
    # fig.append_trace(go.Scatter(x = df['Datetime'], y = df['MACD'], name = "MACD", marker = dict(color = '#2ECC71')), row = 5, col = 1)
    # fig.append_trace(go.Scatter(x = df['Datetime'], y = df['MACDS'], name = "MACDS", marker = dict(color = '#E74C3C')), row = 5, col = 1)
    # fig.append_trace(go.Bar(x = df['Datetime'], y = df['MACDH'], name = "MACDH", marker = dict(color = '#000000')), row = 5, col = 1)
    # fig.add_shape(type = 'line', x0 = df['Datetime'].min(), x1 = df['Datetime'].max(), y0 = 0, y1 = 0, line = dict(color = '#000000', width = 0.5), row = 5, col = 1)
    
    st.plotly_chart(fig)

# yf interval: 1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h, 1d, 5d, 1wk, 1mo, 3mo
def getOverallView(ticker_name):  
    # p = 1d  | i = 1m
    df_1d_1m = getDifferentChartInterval(ticker_name, '1d' , '1m', 'Datetime')
    sleep(5)
    # p = 1d  | i = 5m
    df_1d_5m = getDifferentChartInterval(ticker_name, '1d' , '5m', 'Datetime')
    sleep(5)
    # p = 1d  | i = 15m
    df_1d_15m = getDifferentChartInterval(ticker_name, '1d' , '15m', 'Datetime')
    # sleep(5)
    # p = 30d | i = 1d
    # df_30d_1d = getDifferentChartInterval(ticker_name, '1d' , '30m', 'Datetime')
    
    st.markdown("## {0}".format(ticker_name))
    
    plotYahooAnalysisUsingPlotly(df_1d_1m)
    plotYahooAnalysisUsingPlotly(df_1d_5m)
    plotYahooAnalysisUsingPlotly(df_1d_15m)
    # plotYahooAnalysisUsingPlotly(df_30d_1d)
    
    # col1, col2 = st.columns(2)
    # with col1:
    #     st.markdown("### 1 Day - 1 Minute TimeFrame")
    #     # st.write(df_1d_1m)
    #     plotYahooAnalysisUsingPlotly(df_1d_1m)
    #     # st.write(df_1d_5m)
    # with col2:
    #     st.markdown("### 1 Day - 5 Minute TimeFrame")
    #     # st.write(df_1d_5m)
    #     plotYahooAnalysisUsingPlotly(df_1d_5m)
    # col3, col4 = st.columns(2)
    # with col3:
    #     st.markdown("### 1 Day - 15 Minute TimeFrame")
    #     # st.write(df_1d_15m)
    #     plotYahooAnalysisUsingPlotly(df_1d_15m)
    # with col4:
    #     st.markdown("### 1 Day - 60 Minute TimeFrame")
    #     # st.write(df_30d_1d)
    #     plotYahooAnalysisUsingPlotly(df_30d_1d)
        
getOverallView("INFY.NS")