import streamlit as st
from nsepython import *   
import datetime
import pandas as pd
from streamlit_autorefresh import st_autorefresh

# Run the autorefresh about every 2000 milliseconds (2 seconds) and stop
# after it's been refreshed 100 times.
count = st_autorefresh(interval=2000, limit=100, key="fizzbuzzcounter")

if count == 0:
    st.write("Count is zero")
else:
    st.write(f"Count: {count}")
        
# key = "NIFTY"
# key = "BANKNIFTY"
# key = "SME"
# key = "FO"
# key = "OTHERS"
# key = "ALL"
def nse_preopen(key="NIFTY"):
    returnTo = []
    payload = nsefetch("https://www.nseindia.com/api/market-data-pre-open?key="+key+"")   
    dataList = payload['data']
    for d in dataList:
      
        obj = {}
        obj['lastUpdateTime'] = d['detail']['preOpenMarket']['lastUpdateTime']
        obj['symbol'] = d['metadata']['symbol']
        obj['lastPrice'] = d['metadata']['lastPrice']
        obj['change'] = d['metadata']['change']
        obj['pChange'] = d['metadata']['pChange']
        obj['previousClose'] = d['metadata']['previousClose']
        obj['yearHigh'] = d['metadata']['yearHigh']
        obj['yearLow'] = d['metadata']['yearLow']
        returnTo.append(obj)
    return returnTo

def getSecuritiesInFNO():
    positions = nsefetch('https://www.nseindia.com/api/equity-stockIndices?index=SECURITIES%20IN%20F%26O')

    postions_df = pd.DataFrame(positions['data'])

    postions_df[['symbol', 'identifier', 'series', 'open', 'dayHigh', 'dayLow',
        'lastPrice', 'previousClose', 'change', 'pChange', 'yearHigh', 'yearLow', 'nearWKH', 'nearWKL', 'perChange365d',
        'date365dAgo', 'chart365dPath', 'date30dAgo', 'perChange30d']]
    
    return postions_df.head(25)

def getIndexValues():
    index_df = nse_index()
    index_df = index_df[['timeVal', 'indexName', 'percChange',  'last', 'previousClose', 'high' , 'low', 'open', 'yearHigh', 'yearLow']]
    index_df = index_df[((index_df['indexName'] == 'NIFTY 50') |
                      (index_df['indexName'] == 'NIFTY BANK') |
                     (index_df['indexName'] == 'NIFTY NEXT 50') | 
                    
                     (index_df['indexName'] == 'INDIA VIX')
                     )]
    return index_df

st.markdown("### NSE Events")
st.table(nse_events())

st.markdown("### FII / DII Data")
st.table(nse_fiidii())

pre_open_df = pd.DataFrame(nse_preopen("NIFTY"))
st.markdown("### Pre Open Nifty 50 Stocks")
st.table(pre_open_df)

# st.markdown("### Securities In F & O")
# st.table(getSecuritiesInFNO())

st.markdown("### Index Values")
st.table(getIndexValues())

nse_preopen_movers_in_FO_df = nse_preopen_movers(key="FO")
st.markdown("### FO Stock Movements")
st.table(nse_preopen_movers_in_FO_df)

nse_most_active_by_volume = nse_most_active(type="securities",sort="volume")
st.markdown("### Most Active By Volume")
st.table(nse_most_active_by_volume)


