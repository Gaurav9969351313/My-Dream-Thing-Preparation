from operator import index
from tkinter import N
import pandas as pd
import talib
import streamlit as st
from Lib.patterns import candlestick_patterns 

def app():
    st.markdown("## My Pattern Scanneer")
    st.sidebar.subheader('Pattern:')
    pattern_options = candlestick_patterns.values()
    pattern = st.sidebar.selectbox('', pattern_options, index = 1)
    key = [i for i in candlestick_patterns if candlestick_patterns[i]==pattern]
    pattern_function_name = key[0]
    pattern_function = getattr(talib, pattern_function_name)
    