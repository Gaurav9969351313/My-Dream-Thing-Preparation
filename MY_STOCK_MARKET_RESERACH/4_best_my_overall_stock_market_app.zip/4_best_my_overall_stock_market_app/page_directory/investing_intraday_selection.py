import pandas as pd 
import json
import streamlit as st
import streamlit.components.v1 as components

from Lib.data_sourcing import Data_Sourcing 
from Lib.graph import Visualization
from Lib.indicator_analysis import Indications
from keras.models import load_model
import warnings
import gc
from tradingview_ta import TA_Handler, Interval, Exchange


def getIndicatorValues(y_ticker_name):
    ticker = y_ticker_name.replace(".NS", "")
    ticker = ticker.replace("&", "_")
    ticker = ticker.replace("-", "_")
    indicator_values = TA_Handler(
        symbol=ticker,
        screener="india",
        exchange="NSE",
        interval=Interval.INTERVAL_1_DAY
    )

    df1 = pd.DataFrame([indicator_values.get_analysis().indicators])
    df2 = pd.DataFrame([indicator_values.get_analysis().summary])
    df = pd.concat([df1, df2], axis=1, join='inner')
    
    # df_i = df[['RECOMMENDATION', 'BUY', 'SELL', 'NEUTRAL', 'RSI', 'open', 'low', 'high', 'change', 'volume', 'RSI[1]','ADX','Stoch.K', 'Stoch.D', 'AO[2]','UO','MACD.macd', 'MACD.signal', 'Stoch.K', 'Stoch.D', 'Stoch.K[1]', 'Stoch.D[1]','EMA50', 'SMA50',  'Rec.VWMA', 'VWMA']]
    return df

def app():
    st.markdown("## Intraday Stock Selection using investing.com data files")
    st.code("https://in.investing.com/stock-screener/?sp=country::14|sector::a|industry::a|equityType::a|exchange::46|eq_market_cap::1640000,15280000000000|last::130.13,2000|ADX::20,50|eq_beta::-2,2%3Ceq_market_cap;1")
    # plotCharts("ACC")
    colfu1, colfu2 = st.columns(2)
    with colfu1:
        st.markdown("### Upload Technical Sheet")
        technical_uploaded_file = st.file_uploader("Upload Technical Sheet")
    with colfu2:
        st.markdown("### Upload Performance Sheet")
        performance_uploaded_file = st.file_uploader("Upload Performance Sheet")

    if technical_uploaded_file is not None and performance_uploaded_file is not None:
        df = pd.read_csv(technical_uploaded_file)
        perf_df = pd.read_csv(performance_uploaded_file)
        
        tech_result_df = df.loc[((df['15 Minutes']=="Strong Buy") | (df['15 Minutes']=="Strong Sell")) &
                ((df['Hourly']=="Strong Buy") | (df['Hourly']=="Strong Sell")) &
                ((df['Daily']=="Strong Buy") | (df['Daily']=="Strong Sell")) &
                ((df['Weekly']=="Strong Buy") | (df['Weekly']=="Strong Sell")) &
                ((df['Monthly']=="Strong Buy") | (df['Monthly']=="Strong Sell")) 
        ]
        
        strong_buy_side = df.loc[((df['15 Minutes']=="Strong Buy") & 
                                            (df['Hourly']=="Strong Buy") & 
                                            (df['Daily']=="Strong Buy") &
                                            (df['Weekly']=="Strong Buy") & 
                                            (df['Monthly']=="Strong Buy"))]
        
        strong_sell_side = df.loc[((df['15 Minutes']=="Strong Sell") & 
                                            (df['Hourly']=="Strong Sell") & 
                                            (df['Daily']=="Strong Sell") &
                                            (df['Weekly']=="Strong Sell") & 
                                            (df['Monthly']=="Strong Sell"))]
        
        # strong_buy_side = strong_buy_side.drop(11)
        
        
        st.header("Strong Buy Side")
        df = pd.merge(strong_buy_side, perf_df, on='Name', how='inner')
        st.write(df)

        st.header("Strong Sell Side")
        df = pd.merge(strong_sell_side, perf_df, on='Name', how='inner')
        st.write(df)
        
        mcap_df=pd.read_excel('./page_directory/reports/MCAP31032022.xlsx', sheet_name="Sheet1")
        strong_buy_side['Name'] = strong_buy_side['Name'].str.upper()
        fbdf = pd.merge(strong_buy_side, mcap_df, on='Name', how='inner')
        
        strong_sell_side['Name'] = strong_sell_side['Name'].str.upper()
        fsdf = pd.merge(strong_sell_side, mcap_df, on='Name', how='inner')

        buy_list = fbdf['YahooSymbol'].to_list()   
        sell_list = fsdf['YahooSymbol'].to_list()
        
        for ticker in buy_list:
            print("==============================")
            ind_a_df = pd.DataFrame()
            ind_a_df = getIndicatorValues(ticker)
            ind_a_df['SYMBOL \n'] =  ticker
            st.write(ind_a_df)
            plotCharts(ticker)
            print(ticker)
            print("==============================")
            
        for ticker in sell_list:
            print("==============================")
            ind_a_df = pd.DataFrame()
            ind_a_df = getIndicatorValues(ticker)
            ind_a_df['SYMBOL \n'] =  ticker
            st.write(ind_a_df)
            plotCharts(ticker)
            print(ticker)
            print("==============================")
            

           
            # https://chartink.com/screener/strong-stocks
            
        # data = json.load(open('./page_directory/reference/investing_intraday_selection.json', 'r'))
        # df = pd.json_normalize(data['hits'])
        # df.columns.to_list()

        # df = df[["stock_symbol", "eq_pe_ratio", "eq_one_year_return", "eq_beta", "RSI","STOCH", "CCI", "MACD", "ADX", "WilliamsR", "STOCHRSI", "ATR", "HL", "UO", "ROC", "BullBear", "month_change", "ytd", "week", "month", "year", "3year", "pair_change_percent", "a52_week_high", "a52_week_low", "turnover_volume", "last", "a52_week_high_diff", "a52_week_low_diff"]]

        
def plotCharts(ticker):
    gc.collect()
    action_model = load_model("models/action_prediction_model.h5")
    price_model = load_model("models/price_prediction_model.h5")
    indication = 'Predicted'
    # ticker = "Cummins India Ltd"
    analysis = Visualization("Yahoo! Finance", "1 Day", ticker, indication,action_model,price_model, "Indian S&P BSE SENSEX")
    prediction_fig = analysis.prediction_graph('Stocks')
    st.plotly_chart(prediction_fig, use_container_width = True)
    technical_analysis_fig = analysis.technical_analysis_graph()
    st.plotly_chart(technical_analysis_fig, use_container_width = True) 