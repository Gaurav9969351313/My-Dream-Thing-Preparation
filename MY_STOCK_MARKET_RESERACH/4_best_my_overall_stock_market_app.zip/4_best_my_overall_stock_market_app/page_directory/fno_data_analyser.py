import configparser
import csv
import datetime
import os
import platform
import sys
import time
from typing import Union, Optional, List, Dict, Tuple, TextIO, Any
import bs4
import pandas
import requests
import streamlit as st
from st_aggrid import GridOptionsBuilder, AgGrid, GridUpdateMode, DataReturnMode, JsCode

# st.set_page_config(
#     page_title = 'Intraday Stock Selection',
#     layout = 'wide'
# )

url_oc: str = "https://www.nseindia.com/option-chain"
url_index: str = "https://www.nseindia.com/api/option-chain-indices?symbol="
url_stock: str = "https://www.nseindia.com/api/option-chain-equities?symbol="

url_top_20_index_contracts = "https://www.nseindia.com/api/liveEquity-derivatives?index=top20_contracts"
url_stock_options = "https://www.nseindia.com/api/liveEquity-derivatives?index=stock_opt"

url_symbols: str = "https://www.nseindia.com/products-services/equity-derivatives-list-underlyings-information"

session: requests.Session = requests.Session()
cookies: Dict[str, str] = {}
indices: List[str] = []
stocks: List[str] = []
pandas.set_option('display.max_rows', None)
pandas.set_option('display.max_columns', None)
pandas.set_option('display.width', 400)

first_run: bool = True

headers: Dict[str, str] = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                          'like Gecko) Chrome/80.0.3987.149 Safari/537.36',
            'accept-language': 'en,gu;q=0.9,hi;q=0.8',
            'accept-encoding': 'gzip, deflate, br'}
round_factor: int = 1000 # For Stock = 10
time_difference_factor: int = 5




def set_itm_labels(call_change: float, put_change: float) -> str:
            label: str = "No"
            if put_change > call_change:
                if put_change >= 0:
                    if call_change <= 0:
                        label = "Yes"
                    elif put_change / call_change > 1.5:
                        label = "Yes"
                else:
                    if put_change / call_change < 0.5:
                        label = "Yes"
            if call_change <= 0:
                label = "Yes"
            return label

def app():
    printInitialResults()
    st.markdown("## FNO Data Analyser")
    option_mode = st.sidebar.selectbox('Index', ['Index', 'Stock'], index = 0)
    if option_mode == 'Index':
        url_to_use = url_index
        symbol = st.sidebar.text_input('Symbol', 'NIFTY')
        sp = int(st.sidebar.text_input('Strike Price', '17000'))
    elif option_mode == 'Stock':
        url_to_use = url_stock
        symbol = st.sidebar.text_input('Symbol', 'TCS')
        sp = int(st.sidebar.text_input('Strike Price', '3000'))

    result_df:Any
    result_holder=[]
    
    url: str = url_to_use + symbol
    
    round_factor: int = 1000 if option_mode == 'Index' else 10
    
    try:
        response, json_data = get_data(url, round_factor, option_mode, symbol)
        av_dates = []
        for dates in json_data['records']['expiryDates']:
            av_dates.append(dates)
        expiry_date = st.sidebar.selectbox('Expiry', av_dates, 0)    
       
        
    except TypeError:
        print("Error")
        
    if response is None or json_data is None:
        print("Response Null")
    
    df: pandas.DataFrame = pandas.read_json(response.text)
    df = df.transpose()


    ce_values: List[dict] = [data['CE'] for data in json_data['records']['data'] if
                                "CE" in data and data['expiryDate'].lower() == expiry_date.lower()]
    pe_values: List[dict] = [data['PE'] for data in json_data['records']['data'] if
                                "PE" in data and data['expiryDate'].lower() == expiry_date.lower()]

    points: float = pe_values[0]['underlyingValue']
    if points == 0:
        for item in pe_values:
            if item['underlyingValue'] != 0:
                points = item['underlyingValue']
                break
    ce_data_f: pandas.DataFrame = pandas.DataFrame(ce_values)
    pe_data_f: pandas.DataFrame = pandas.DataFrame(pe_values)

    columns_ce: List[str] = ['openInterest', 'changeinOpenInterest', 'totalTradedVolume', 'impliedVolatility',
                                'lastPrice',
                                'change', 'bidQty', 'bidprice', 'askPrice', 'askQty', 'strikePrice']
    columns_pe: List[str] = ['strikePrice', 'bidQty', 'bidprice', 'askPrice', 'askQty', 'change', 'lastPrice',
                                'impliedVolatility', 'totalTradedVolume', 'changeinOpenInterest', 'openInterest']
    ce_data_f = ce_data_f[columns_ce]
    pe_data_f = pe_data_f[columns_pe]
    merged_inner: pandas.DataFrame = pandas.merge(left=ce_data_f, right=pe_data_f, left_on='strikePrice',
                                                    right_on='strikePrice')
    merged_inner.columns = ['Open Interest', 'Change in Open Interest', 'Traded Volume', 'Implied Volatility',
                            'Last Traded Price', 'Net Change', 'Bid Quantity', 'Bid Price', 'Ask Price',
                            'Ask Quantity', 'Strike Price', 'Bid Quantity', 'Bid Price', 'Ask Price',
                            'Ask Quantity', 'Net Change', 'Last Traded Price', 'Implied Volatility',
                            'Traded Volume', 'Change in Open Interest', 'Open Interest']
    current_time: str = df['timestamp']['records']

    try:
        entire_oc: pandas.DataFrame
        current_time: str
        points: float
        entire_oc, current_time, points = merged_inner, current_time, points
        # df = getDataFrame(entire_oc, selected_expiry_date, sp, current_time, points)
    except TypeError:
        print("Error")

    str_current_time: str = current_time.split(" ")[1]
    current_date: datetime.date = datetime.datetime.strptime(current_time.split(" ")[0], '%d-%b-%Y').date()
    current_time: datetime.time = datetime.datetime.strptime(current_time.split(" ")[1], '%H:%M:%S').time()

    print(str(current_date) + " " + str(current_time))

    previous_date = current_date
    previous_time = current_time

    call_oi_list: List[int] = []
    for i in range(len(entire_oc)):
        int_call_oi: int = int(entire_oc.iloc[i, [0]][0])
        call_oi_list.append(int_call_oi)
    call_oi_index: int = call_oi_list.index(max(call_oi_list))
    max_call_oi: float = round(max(call_oi_list) / round_factor, 1)
    max_call_oi_sp: float = float(entire_oc.iloc[call_oi_index]['Strike Price'])

    put_oi_list: List[int] = []
    for i in range(len(entire_oc)):
        int_put_oi: int = int(entire_oc.iloc[i, [20]][0])
        put_oi_list.append(int_put_oi)
    put_oi_index: int = put_oi_list.index(max(put_oi_list))
    max_put_oi: float = round(max(put_oi_list) / round_factor, 1)
    max_put_oi_sp: float = float(entire_oc.iloc[put_oi_index]['Strike Price'])

    sp_range_list: List[float] = []
    for i in range(put_oi_index, call_oi_index + 1):
        sp_range_list.append(float(entire_oc.iloc[i]['Strike Price']))

    max_call_oi_2: float
    max_call_oi_sp_2: float
    max_put_oi_2: float
    max_put_oi_sp_2: float
    if max_call_oi_sp == max_put_oi_sp:
        max_call_oi_2 = max_call_oi
        max_call_oi_sp_2 = max_call_oi_sp
        max_put_oi_2 = max_put_oi
        max_put_oi_sp_2 = max_put_oi_sp
    elif len(sp_range_list) == 2:
        max_call_oi_2 = round((entire_oc[entire_oc['Strike Price'] == max_put_oi_sp].iloc[0, 0]) /
                                    round_factor, 1)
        max_call_oi_sp_2 = max_put_oi_sp
        max_put_oi_2 = round((entire_oc[entire_oc['Strike Price'] == max_call_oi_sp].iloc[0, 20]) /
                                    round_factor, 1)
        max_put_oi_sp_2 = max_call_oi_sp
    else:
        call_oi_list_2: List[int] = []
        for i in range(put_oi_index, call_oi_index):
            int_call_oi_2: int = int(entire_oc.iloc[i, [0]][0])
            call_oi_list_2.append(int_call_oi_2)
        call_oi_index_2: int = put_oi_index + call_oi_list_2.index(max(call_oi_list_2))
        max_call_oi_2 = round(max(call_oi_list_2) / round_factor, 1)
        max_call_oi_sp_2 = float(entire_oc.iloc[call_oi_index_2]['Strike Price'])

        put_oi_list_2: List[int] = []
        for i in range(put_oi_index + 1, call_oi_index + 1):
            int_put_oi_2: int = int(entire_oc.iloc[i, [20]][0])
            put_oi_list_2.append(int_put_oi_2)
        put_oi_index_2: int = put_oi_index + 1 + put_oi_list_2.index(max(put_oi_list_2))
        max_put_oi_2 = round(max(put_oi_list_2) / round_factor, 1)
        max_put_oi_sp_2 = float(entire_oc.iloc[put_oi_index_2]['Strike Price'])

    total_call_oi: int = sum(call_oi_list)
    total_put_oi: int = sum(put_oi_list)
    put_call_ratio: float
    try:
        put_call_ratio = round(total_put_oi / total_call_oi, 2)
    except ZeroDivisionError:
        put_call_ratio = 0
        
# def getDataFrame(entire_oc, expiry_date, sp, current_time, points):
    try:
        index: int = int(entire_oc[entire_oc['Strike Price'] == sp].index.tolist()[0])
    except IndexError as err:
        print(err, sys.exc_info()[0], "10")
        
    a: pandas.DataFrame = entire_oc[['Change in Open Interest']][entire_oc['Strike Price'] == sp]


    b1: pandas.Series = a.iloc[:, 0]
    c1: int = int(b1.get(index))
    b2: pandas.Series = entire_oc.iloc[:, 1]
    c2: int = int(b2.get((index + 1), 'Change in Open Interest'))
    b3: pandas.Series = entire_oc.iloc[:, 1]
    c3: int = int(b3.get((index + 2), 'Change in Open Interest'))
    if isinstance(c2, str):
        c2 = 0
    if isinstance(c3, str):
        c3 = 0
    call_sum: float = round((c1 + c2 + c3) / round_factor, 1)
    if call_sum == -0:
        call_sum = 0.0
    call_boundary: float = round(c3 / round_factor, 1)

    o1: pandas.Series = a.iloc[:, 1]
    p1: int = int(o1.get(index))
    o2: pandas.Series = entire_oc.iloc[:, 19]
    p2: int = int(o2.get((index + 1), 'Change in Open Interest'))
    p3: int = int(o2.get((index + 2), 'Change in Open Interest'))
    p4: int = int(o2.get((index + 4), 'Change in Open Interest'))
    o3: pandas.Series = entire_oc.iloc[:, 1]
    p5: int = int(o3.get((index + 4), 'Change in Open Interest'))
    p6: int = int(o3.get((index - 2), 'Change in Open Interest'))
    p7: int = int(o2.get((index - 2), 'Change in Open Interest'))
    if isinstance(p2, str):
        p2 = 0
    if isinstance(p3, str):
        p3 = 0
    if isinstance(p4, str):
        p4 = 0
    if isinstance(p5, str):
        p5 = 0
    put_sum: float = round((p1 + p2 + p3) / round_factor, 1)
    put_boundary: float = round(p1 / round_factor, 1)
    difference: float = round(call_sum - put_sum, 1)
    call_itm: float
    if p5 == 0:
        call_itm = 0.0
    else:
        call_itm = round(p4 / p5, 1)
        if call_itm == -0:
            call_itm = 0.0
    if isinstance(p6, str):
        p6 = 0
    if isinstance(p7, str):
        p7 = 0
    put_itm: float
    if p7 == 0:
        put_itm = 0.0
    else:
        put_itm = round(p6 / p7, 1)
        if put_itm == -0:
            put_itm = 0.0
    
    notifications = True

    max_call_oi_val=max_call_oi
    max_call_oi_sp_val=max_call_oi_sp

    print(str(max_call_oi_sp_val) + " " +  str(max_call_oi_val))

    max_call_oi_2_val=max_call_oi_2
    max_call_oi_sp_2_val=max_call_oi_sp_2

    print(str(max_call_oi_sp_2_val) + " " +  str(max_call_oi_2_val))

    max_put_oi_val=max_put_oi
    max_put_oi_sp_val=max_put_oi_sp

    print(str(max_put_oi_sp_val) + " " +  str(max_put_oi_val))

    max_put_oi_2_val=max_put_oi_2
    max_put_oi_sp_2_val=max_put_oi_sp_2

    print(str(max_put_oi_sp_2_val) + " " +  str(max_put_oi_2_val))

    
    if call_sum >= put_sum:
        oi_label = "Bearish"
        oi_label_bg = "red"
    else:
        oi_label = "Bullish"
        oi_label_bg = "green"

    if put_call_ratio >= 1:
        pcr_val = put_call_ratio 
        pcr_bg="green"
    else:
        pcr_val = put_call_ratio
        pcr_bg="red"
        

    call_itm_bg = ""      
    call: str = set_itm_labels(call_change=p5, put_change=p4)

    if call == "No":
        call_itm_val ="No"
        call_itm_bg="default"
    else:
        call_itm_val="Yes" 
        call_itm_bg="green"
        

    put: str = set_itm_labels(call_change=p7, put_change=p6)

    put_itm_bg=""
    if put == "No":
        put_itm_val="No"
        put_itm_bg="default"
    else:
        put_itm_val="Yes" 
        put_itm_bg="red"
        
    call_exits_label: str

    call_exits_bg=""
    if call_boundary <= 0:
        call_exits_label = "Yes"
        call_exits_bg = "green"
    elif call_sum <= 0:
        call_exits_label = "Yes"
        call_exits_bg = "green"
    else:
        call_exits_label = "No"
        call_exits_bg = "default"
        
    put_exits_label: str

    put_exits_bg=""
    if put_boundary <= 0:
        put_exits_label = "Yes"
        put_exits_bg = "red"
    elif put_sum <= 0:
        put_exits_label = "Yes"
        put_exits_bg = "red"
    else:
        put_exits_label = "No"
        put_exits_bg = "default"
        
        
    grid_data = {}
    
    grid_data['str_current_time'] = str_current_time 
    grid_data['points'] = points 
    grid_data['call_sum'] = call_sum                               
    grid_data['put_sum'] = put_sum 
    grid_data['difference'] = difference                                
    grid_data['call_boundary'] = call_boundary 
    grid_data['put_boundary'] = put_boundary 
    grid_data['call_itm'] = call_itm
    grid_data['put_itm'] = put_itm
    
    result_holder.append(grid_data)
    result_df = pandas.DataFrame.from_records(grid_data, index=['1','2'])
    result_df = result_df[['str_current_time', 'points', 'call_sum', 'put_sum', 'difference', 'call_boundary', 'put_boundary', 'call_itm', 'put_itm']]
    st.write(result_df)
    print(result_df)

    print("oi_label " + str(oi_label) + " " + str(oi_label_bg))
    print("pcr_val " + str(pcr_val) + " " + str(pcr_bg))
    print("call_exits_label " + str(call_exits_label) + " " + str(call_exits_bg))
    print("put_exits_label " + str(put_exits_label) + " " + str(put_exits_bg))
    print("call_itm_val " + str(call_itm_val) + " " + str(call_itm_bg))
    print("put_itm_val " + str(put_itm_val) + " " + str(put_itm_bg))
    
    colfu1, colfu2 = st.columns(2)
    with colfu1:
        st.markdown("### Open Interest Upper Boundry")        
        st.metric(label="OI", value=oi_label, delta=getColor(oi_label_bg))
        st.metric(label="Call Exits", value=call_exits_label, delta=getColor(call_exits_bg))
        st.metric(label="Call ITM", value=call_itm_val, delta=getColor(call_itm_bg))

    with colfu2:
        st.markdown("### Open Interest Lower Boundry")
        st.metric(label="PCR", value=pcr_val, delta=getColor(pcr_bg))
        st.metric(label="Put Exits", value=put_exits_label, delta=getColor(put_exits_bg))
        st.metric(label="Put ITM", value=put_itm, delta=getColor(put_itm_bg))
        
    strike_df = entire_oc[entire_oc['Strike Price'] == sp]
    print(expiry_date)

    call = symbol + " " + expiry_date.replace("-"," ") + " " + str(sp) + " CE"
    put  =  symbol + " " + expiry_date.replace("-"," ") + " " + str(sp) + " PE"

    dff = strike_df["Last Traded Price"]

    data = {}
    data['Call'] = call
    data['Call LTP'] = dff.iat[0, 0]

    data['Put'] = put
    data['Put LTP'] = dff.iat[0, 1]

    result_df = pandas.DataFrame.from_dict(data, orient ='index')
    result_df.transpose()
    
    st.write(result_df.transpose())
        
def getColor(val):
    if val == "red":
        return "-" + val
    elif val == "green":
        return "+"+val
    else:
        return "default"   

def get_data(url, round_factor,option_mode,symbol) :
        if first_run:
            return get_data_first_run(url, round_factor,option_mode,symbol)
        else:
            return get_data_refresh(url, round_factor,option_mode,symbol)

def get_data_first_run(url, round_factor,option_mode,symbol) :
    request: Optional[requests.Response] = None
    response: Optional[requests.Response] = None
    print(url)
    try:
        request = session.get(url_oc, headers=headers, timeout=5)
        cookies = dict(request.cookies)
        response = session.get(url, headers=headers, timeout=5, cookies=cookies)
    except Exception as err:
        print(request)
        print(response)
        print(err, sys.exc_info()[0], "1")
        return
    json_data: Any
    if response is not None:
        try:
            json_data = response.json()
        except Exception as err:
            print(response)
            json_data = {}
    else:
        json_data = {}
        
    # first_run = False
    return response, json_data

def get_data_refresh(url, round_factor, option_mode,symbol):
    request: Optional[requests.Response] = None
    response: Optional[requests.Response] = None
    url: str = url_index + symbol if option_mode == 'Index' else url_stock + symbol
    try:
        response = session.get(url, headers=headers, timeout=5, cookies=cookies)
        if response.status_code == 401:
            session.close()
            session = requests.Session()
            request = session.get(url_oc, headers=headers, timeout=5)
            cookies = dict(request.cookies)
            response = session.get(url, headers=headers, timeout=5, cookies=cookies)
            print("reset cookies")
    except Exception as err:
        print(request)
        print(response)
        print(err, sys.exc_info()[0], "4")
        try:
            session.close()
            session = requests.Session()
            request = session.get(url_oc, headers=headers, timeout=5)
            cookies = dict(request.cookies)
            response = session.get(url, headers=headers, timeout=5, cookies=cookies)
            print("reset cookies")
        except Exception as err:
            print(request)
            print(response)
            print(err, sys.exc_info()[0], "5")
            return
    if response is not None:
        try:
            json_data: Any = response.json()
        except Exception as err:
            print(response)
            print(err, sys.exc_info()[0], "6")
            json_data = {}
    else:
        json_data = {}
    if json_data == {}:
        return

    return response, json_data

def getDataFromNSE(url):
    request = session.get(url_oc, headers=headers, timeout=5)
    cookies = dict(request.cookies)
    response = session.get(url, headers=headers, timeout=5, cookies=cookies)
    json_data = response.json()
    # print(json_data["data"])
    avl_recs = []
    for rec in json_data['data']:
        avl_recs.append(rec)
    df = pandas.DataFrame(avl_recs)
    return df 

def printInitialResults():
    with st.expander("Top 20 Index Contracts"):
        df = getDataFromNSE(url_top_20_index_contracts)
        df = df[['underlying', 'strikePrice', 'expiryDate', 'optionType',  'lastPrice', 'change', 'pChange', 'openInterest']]
        
        gb = GridOptionsBuilder.from_dataframe(df)
        gb.configure_default_column(groupable=True, value=True, enableRowGroup=True, aggFunc='sum', editable=True)
        gb.configure_selection(selection_mode='single', use_checkbox=True, groupSelectsChildren=True, groupSelectsFiltered=True)
        
        gb.configure_grid_options(domLayout='normal')
        gridOptions = gb.build()
        
        grid_response = AgGrid(
            df, 
            gridOptions=gridOptions,
            width='100%',
            data_return_mode='FILTERED_AND_SORTED', 
            fit_columns_on_grid_load=False,
            allow_unsafe_jscode=True, #Set it to True to allow jsfunction to be injected
            enable_enterprise_modules=False
        )

        st.write(grid_response['selected_rows'])
    with st.expander("Most Active Stock Options"):
        dff = getDataFromNSE(url_stock_options)
        dff = dff[['underlying', 'strikePrice', 'expiryDate', 'optionType',  'lastPrice', 'change', 'pChange', 'openInterest']]
        st.write(dff)
        
    