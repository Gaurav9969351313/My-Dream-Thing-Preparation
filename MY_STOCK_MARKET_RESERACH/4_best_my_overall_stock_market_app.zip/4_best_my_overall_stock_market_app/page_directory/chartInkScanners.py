from concurrent.futures import thread
import logging
import os
from datetime import datetime as dt
from datetime import timedelta as td
from time import sleep

import pandas as pd
import pytz
import requests
from bs4 import BeautifulSoup
import streamlit as st
from chartInkConfig import scannners

from streamlit_autorefresh import st_autorefresh

log = logging.getLogger(__name__)
# NOTE while creating date objects you can use zone info which is very helpful when you are running scripts on outside India location
zone = pytz.timezone('Asia/Kolkata')

def get_scanned_results(scanner_url, payload):
    with requests.Session() as s:

        r = s.get(scanner_url)
        soup = BeautifulSoup(r.text, "html.parser")
        csrf = soup.select_one("[name='csrf-token']")['content']
        s.headers['x-csrf-token'] = csrf

        process_url = 'https://chartink.com/screener/process'

        r = s.post(process_url, data=payload)
        df = pd.DataFrame()
        for item in r.json()['data']:
            df = df.append(item, ignore_index=True)
        # NOTE Sorting done by ascending price so that stock with less price can be purchased before
        # Costly stocks may be rejected if there is no capital
        df.sort_values(by=['close'], inplace=True)
        df.drop('sr', axis=1, inplace=True)
        df.reset_index(inplace=True)
        df.drop('index', axis=1, inplace=True)

        print(f'number of stocks :: {len(df)}')
        if len(df) > 10:
            print('returning only first 10 stocks')
            df = df.head(10)
        return df

# Run the autorefresh about every 2000 milliseconds (2 seconds) and stop
# after it's been refreshed 100 times.
count = st_autorefresh(interval=20000, limit=100, key="fizzbuzzcounter")

if count == 0:
    st.write("Count is zero")
else:
    st.write(f"Count: {count}")
    

for scan in scannners:
    st.markdown('### {}'.format(scan['scanner_name']))
    st.table(get_scanned_results(scan['scanner_url'], scan['payload']))
    sleep(5)
