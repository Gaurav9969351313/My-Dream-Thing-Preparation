import requests
import numpy as np
import pandas as pd
from datetime import timedelta, date
from tradingview_ta import TA_Handler, Interval, Exchange
import streamlit as st
import os.path
import base64

pd.set_option('display.max_colwidth', None)

reference_df_500 = pd.read_csv('./page_directory/reference/NIFTY500.csv')
reference_df_200 = pd.read_csv('./page_directory/reference/NIFTY200.csv')

reports= [
    {"key": "fii_dii_open_interest_report" , "url": "https://www1.nseindia.com/content/nsccl/", "fileName" : "fao_participant_oi_{0}.csv"},
    {"key": "daily_security_wise_dilivery_report_url", "url":"https://archives.nseindia.com/archives/equities/mto/", "fileName": "MTO_{0}.DAT"}
]

def getIndicatorValues(y_ticker_name):
    ticker = y_ticker_name.replace(".NS", "")
    ticker = ticker.replace("&", "_")
    ticker = ticker.replace("-", "_")
    indicator_values = TA_Handler(
        symbol=ticker,
        screener="india",
        exchange="NSE",
        interval=Interval.INTERVAL_1_DAY
    )

    df1 = pd.DataFrame([indicator_values.get_analysis().indicators])
    df2 = pd.DataFrame([indicator_values.get_analysis().summary])
    df = pd.concat([df1, df2], axis=1, join='inner')
    
    df_i = df[['RECOMMENDATION', 'BUY', 'SELL', 'NEUTRAL', 'RSI', 'open', 'low', 'high', 'change', 'volume', 'RSI[1]','ADX','Stoch.K', 'Stoch.D', 'AO[2]','UO','MACD.macd', 'MACD.signal', 'Stoch.K', 'Stoch.D', 'Stoch.K[1]', 'Stoch.D[1]','EMA50', 'SMA50',  'Rec.VWMA', 'VWMA']]
    return df_i

def getYesterdayDate():
    yesterday_date = date.today() - timedelta(days=2)
    dd = yesterday_date.day
    mm = yesterday_date.month
    yyyy = yesterday_date.year

    if(dd<9):
        day = str("0") + str(dd)
    else: 
        day = str(dd)
    
    if(mm<9):
        month = str("0") + str(mm)
    else:
        month = str(mm)
        
    return day + month + str(yyyy)

def paginateWithTabs(df,numberOfRowsPerTab):
    rows = len(df.axes[0])
    pages = round(rows/numberOfRowsPerTab)
    tabs_arr = []
    for p in range(0,pages):
        tabs_arr.append("Data " + str(p))
    tabs = st.tabs(tabs_arr)
    for index,tab in enumerate(tabs):
        with tab:
            st.table(df[index*numberOfRowsPerTab: index*numberOfRowsPerTab+numberOfRowsPerTab])
            
def get_table_download_link_csv(df,file_name):
    csv = df.to_csv().encode()
    b64 = base64.b64encode(csv).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="{file_name}" target="_blank">Download Report</a>'
    return href
    

def printAnalysis():
    yesterday_date = getYesterdayDate()

    for rpt in reports:     
        fileName = rpt["fileName"].format(yesterday_date)
        path = './page_directory/reports/' + fileName
         # Step 1: Check file is present or not else Download
        if(os.path.exists(path)):
            print("Report File Is Present")
        else:
            report_file = requests.get( rpt["url"] + fileName)
            open(path, 'wb').write(report_file.content)
    
        if(fileName.endswith(".DAT")):
            gt_dilivery_report = 'gt_dilivery_{0}.csv'.format( yesterday_date)
            if(os.path.exists('./page_directory/reports/' + gt_dilivery_report)):
                print("File Is Present")
                df_overall = pd.read_csv('./page_directory/reports/' + gt_dilivery_report)
            else: 
                print("File NOT Present")
                print("Process DAT")
                data = pd.read_csv(path, sep='|', header=0, skipinitialspace=True)
                data.dropna(inplace=True)
                df = data['Security Wise Delivery Position - Compulsory Rolling Settlement']
                dff = pd.DataFrame([sub.split(",") for sub in df])
                data_df = dff.iloc[2:]
                data_df.drop(columns=[data_df.columns[0],data_df.columns[1]], axis=1, inplace=True)
                data_df.columns = data_df.iloc[0]
                df = data_df.iloc[1:].reset_index(drop=True)
                df.rename(columns = {'Name of Security': 'SYMBOL \n', None: 'dpChange'}, inplace = True)
                df = pd.merge(reference_df_200, df, on='SYMBOL \n', how='inner')
                df['dpChange'] = df['dpChange'].astype(float)
                
                # df['Away from 52 week High'] = ((float(df['52W H \n']) - float(df['LTP \n']))/float(df['52W H \n'])) * 100
                sorted_df = df.sort_values(by='dpChange', ascending=False)
                f_df = sorted_df.drop(['VOLUME \n(shares)', 'VALUE ',  'Quantity Traded', 'Deliverable Quantity(gross across client level)', '% of Deliverable Quantity to Traded Quantity'], axis=1).drop_duplicates(subset=['SYMBOL \n'])

                ################# Indocaor Analysis Starts from here #####################
                
                indicator_dfs = []
                for ind in f_df.index:
                    print(f_df['SYMBOL \n'][ind])
                    ind_a_df = pd.DataFrame()
                    ind_a_df = getIndicatorValues(f_df['SYMBOL \n'][ind])
                    ind_a_df['SYMBOL \n'] =  f_df['SYMBOL \n'][ind]
                    indicator_dfs.append(ind_a_df)
                    
                final_indicator_df = pd.concat(indicator_dfs)
                
                df_a = pd.merge(f_df, final_indicator_df, on='SYMBOL \n', how='inner')
                
                df_overall = df_a.drop([ 'OPEN \n', 'HIGH \n', 'LOW \n', 'PREV. CLOSE \n', 'open', 'low', 'high', 'change', 'volume','ADX', 'Stoch.K', 'Stoch.D', 'AO[2]', 'UO', 'Stoch.K[1]', 'Stoch.D[1]', 'Rec.VWMA', 'VWMA'], axis=1)
                df_overall.to_csv('./page_directory/reports/' + gt_dilivery_report)
            
            st.markdown("### Delivery Percentage wise analysis + various indicators")
            st.markdown(get_table_download_link_csv(df_overall, gt_dilivery_report), unsafe_allow_html=True)
            paginateWithTabs(df_overall, 25)
            df_overall['RSI'] = df_overall['RSI'].astype(float)
            filter_rsi = st.text_input('RSI Less Than')
            st.markdown("### RSI Less Than")
            rslt_df = df_overall[df_overall['RSI'] < float(filter_rsi)] 
            st.table(rslt_df)


            
        elif(rpt['key']=="fii_dii_open_interest_report"):
            data_df= pd.read_csv(path)
            data_df.columns = data_df.iloc[0]
            df = data_df.iloc[1:].reset_index(drop=True)
            df['Future Index Long'] = df['Future Index Long'].astype(float)
            df['Future Index Short'] = df['Future Index Short'].astype(float)
            
            df['Option Index Call Long'] = df['Option Index Call Long'].astype(float)
            df['Option Index Put Long'] = df['Option Index Put Long'].astype(float) 
            df['Option Index Call Short'] = df['Option Index Call Short'].astype(float) 
            df['Option Index Put Short'] = df['Option Index Put Short'].astype(float)
            
            total_contracts = df['Future Index Long'] +  df['Future Index Short']
            
            result_df = pd.DataFrame()
            result_df["Client Type"] = df['Client Type']
            result_df["FutureIndexLongP"]  = (df['Future Index Long']/total_contracts)*100
            result_df["FutureIndexShortP"] = (df['Future Index Short']/total_contracts)*100
            
            options_tc =  df['Option Index Call Long'] + df['Option Index Put Short'] + df['Option Index Put Long'] + df['Option Index Call Short']
            
            result_df["IndexGoUp"]  = ((df['Option Index Call Long']+df['Option Index Put Short'])/options_tc)*100
            result_df["IndexGoDown"] = ((df['Option Index Put Long'] + df['Option Index Call Short'])/options_tc)*100    
            result_df = result_df.drop(4)
            st.markdown("### FII/DII Open Interest Analysis")
            st.table(result_df)
            
def app():
    st.markdown("## Analysis From NSE Daily Report")
    printAnalysis()
        
        
    