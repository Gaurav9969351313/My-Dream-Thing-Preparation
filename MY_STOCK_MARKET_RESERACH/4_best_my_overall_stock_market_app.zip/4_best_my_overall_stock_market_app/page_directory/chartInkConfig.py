scannners = [
    {   'scanner_name': 'Mean Reversion',
        'scanner_url': 'https://chartink.com/screener/copy-vishal-mehta-mean-reversion-56',
        'payload': {
            'scan_clause': '( {33489} ( latest close > latest sma( close, 200 ) and latest rsi( 2 ) > 50 and '\
            'latest close > 1 day ago close * 1.03 and latest close > 200 and latest close < 5000 and latest close > ( 4 days ago close * 1.0 ) ) ) '
        }
    },
    {   'scanner_name': 'Potential Breakouts',
        'scanner_url': 'https://chartink.com/screener/potential-breakouts',
        'payload': { 
             'scan_clause': '( {cash} ( latest close * 1.05 > latest max( 200 , latest high ) and latest max( 30 , latest high ) <= 30 days ago max( 200 , latest high ) and latest volume > latest sma( volume,50 ) and latest close > 90 ) )' 
        }
    },
    {   'scanner_name': 'Intraday Bearish Scanner',
        'scanner_url': 'https://chartink.com/screener/stockinsight-intraday-bearish-scanner',
        'payload': { 
             'scan_clause': '( {33489} ( ( ( [0] 5 minute high - [0] 5 minute close ) / [0] 5 minute close ) * 100 >= 0.5 and latest close >= 100 and [0] 15 minute close < [0] 15 minute supertrend( 10,3 ) and latest close < 1 day ago low and latest close < latest open ) ) '
        }
    },
    {   'scanner_name': 'Intraday Bullish Scanner',
        'scanner_url': 'https://chartink.com/screener/stockinsight-intraday-bullish-scanner',
        'payload': { 
             'scan_clause': '( {33489} ( ( ( [0] 5 minute close - [0] 5 minute low ) / [0] 5 minute low ) * 100 >= 0.5 and latest close >= 100 and [0] 15 minute close > [0] 15 minute supertrend( 10,3 ) and latest close > 1 day ago high and latest close > latest open ) ) '
        }
    } 
]