from tradingview_ta import TA_Handler, Interval, Exchange
import pandas as pd
import datetime as dt
import yfinance as yf
import talib
from Lib.patterns import candlestick_patterns

# https://tvdb.brianthe.dev/

tesla = TA_Handler(
    symbol="ACC",
    screener="india",
    exchange="NSE",
    interval=Interval.INTERVAL_1_DAY
)

df = pd.DataFrame([tesla.get_analysis().indicators])
df_i = df[['open', 'low', 'high', 'change', 'volume', 'RSI', 'RSI[1]', 'MACD.macd', 'MACD.signal', 'Stoch.K', 'Stoch.D', 'Stoch.K[1]', 'Stoch.D[1]','EMA50', 'SMA50',  'Rec.VWMA', 'VWMA']]
df_i



INTERVAL = ['1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', '5d', '1wk', '1mo', '3mo']
TICKER_LIST = ['TCS.NS'] # , 
PERIOD_LIST = ['1d','7d','max']

def getData(ticker_list, period_index, interval_index):
    df = yf.download(tickers = ticker_list, period = PERIOD_LIST[period_index], interval = INTERVAL[interval_index], 
                                    auto_adjust = True, prepost = True, threads = True, proxy = None).reset_index()
    return df

def getPattern(df, pattern_function_name): 
    pattern_function = getattr(talib, pattern_function_name)
    results = pattern_function(df['Open'], df['High'], df['Low'], df['Close'])
    df[pattern_function_name] = results
    return df

data_df = getData(TICKER_LIST, 2, 8)

for pattern_function_name in candlestick_patterns.keys():
    df = getPattern(data_df, pattern_function_name)


function_name = "CDLMARUBOZU"
engulfing_days = df[df[function_name] != 0]
print(engulfing_days[["Date", "Open","High","Low","Close",function_name]].tail(3))



==============================================================================================


import datetime as dt
import yfinance as yf
import talib
from Lib.patterns import candlestick_patterns

PERIOD_LIST = ['1d','7d','max']
INTERVAL = ['1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', '5d', '1wk', '1mo', '3mo']
TICKER_LIST = ['TCS.NS', 'INFY.NS'] # , 

PORTFOLIO_TICKER_LIST = ['ITC.NS', 'BAJFINANCE.NS','BAJAJFINSV.NS','SILVERBEES.NS','DELTACORP.NS','DMART.NS','COALINDIA.NS','DEEPAKNTR','BHARTIARTL.NS','HDFC.NS','IOCL.NS', 'HDFCBANK.NS', 'AARTIIND.NS', 'UPL.NS', 'ASIANPAINT.NS', 'AFFLE.NS', 'PIDILITE.NS', 'INFY.NS','LT.NS','DIXION.NS', 'HAL.NS']

def getData(ticker_list, period_index, interval_index):
    df = yf.download(tickers = ticker_list, period = PERIOD_LIST[period_index], interval = INTERVAL[interval_index], 
                                    auto_adjust = True, prepost = True, threads = True, proxy = None).reset_index()
    return df

def getPattern(df, pattern_function_name): 
    pattern_function = getattr(talib, pattern_function_name)
    results = pattern_function(df['Open'], df['High'], df['Low'], df['Close'])
    df[pattern_function_name] = results
    return df

data_df = getData(TICKER_LIST, 0, 8)

# for pattern_function_name in candlestick_patterns.keys():
#     df = getPattern(data_df, pattern_function_name)

df = data_df.tail(10)

columns=[]
for x in df.columns.to_list():
    columns.append('-'.join([list(x)[0],list(x)[1]]))

df.columns=columns
df
================================================================================================
import datetime as dt
import yfinance as yf
import talib
from Lib.patterns import candlestick_patterns
import pandas as pd
from tradingview_ta import TA_Handler, Interval, Exchange

PERIOD_LIST = ['1d','7d','max']
INTERVAL = ['1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', '5d', '1wk', '1mo', '3mo'] 
TICKER_LIST = ['ITC.NS', 'BAJFINANCE.NS','BAJAJFINSV.NS','SILVERBEES.NS','DELTACORP.NS','DMART.NS','COALINDIA.NS','DEEPAKNTR.NS','BHARTIARTL.NS','HDFC.NS','IOC.NS', 'HDFCBANK.NS', 'AARTIIND.NS', 'UPL.NS', 'ASIANPAINT.NS', 'AFFLE.NS', 'PIDILITIND.NS', 'INFY.NS','LT.NS','DIXON.NS', 'HAL.NS']

def getData(ticker_list, period_index, interval_index):
    df = yf.download(tickers = ticker_list, period = PERIOD_LIST[period_index], interval = INTERVAL[interval_index], 
                                    auto_adjust = True, prepost = True, threads = True, proxy = None).reset_index()
    return df

def getPattern(df, pattern_function_name): 
    pattern_function = getattr(talib, pattern_function_name)
    results = pattern_function(df['Open'], df['High'], df['Low'], df['Close'])
    df[pattern_function_name] = results
    return df

data_arr = []

def getIndicatorValues(y_ticker_name):
    ticker = y_ticker_name.replace(".NS", "")
    indicator_values = TA_Handler(
        symbol=ticker,
        screener="india",
        exchange="NSE",
        interval=Interval.INTERVAL_1_DAY
    )

    df = pd.DataFrame([indicator_values.get_analysis().indicators])
    df_i = df[['open', 'low', 'high', 'change', 'volume', 'RSI', 'RSI[1]', 'MACD.macd', 'MACD.signal', 'Stoch.K', 'Stoch.D', 'Stoch.K[1]', 'Stoch.D[1]','EMA50', 'SMA50',  'Rec.VWMA', 'VWMA']]
    return df_i

def getPortfolioData(ticker_list):
    for ticker in ticker_list:
        ticker_data_obj = {}
        data_df = getData(ticker, 2, 8)
        for pattern_function_name in candlestick_patterns.keys():
            df = getPattern(data_df, pattern_function_name)
        ticker_data_obj["df"] = df
        ticker_data_obj["ticker_name"] = ticker
        ticker_data_obj["indicator_df"] = getIndicatorValues(ticker)
        data_arr.append(ticker_data_obj)
    return data_arr

arr = getPortfolioData(TICKER_LIST)
arr


