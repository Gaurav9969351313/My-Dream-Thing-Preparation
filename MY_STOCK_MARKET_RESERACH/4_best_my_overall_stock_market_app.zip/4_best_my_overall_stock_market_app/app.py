from tkinter.messagebox import NO
import streamlit as st
from multipage import MultiPage
from page_directory import mfTracker, stockTracker, ABuySellStock, PatternScanner, dailyReportAnalysis, investing_intraday_selection, fno_data_analyser

# st.set_page_config(
#     page_title = 'Intraday Stock Selection',
#     layout = 'wide'
# )

number = 1000
max_width_str = f"max-width: " + str(number) + "px;"
st.markdown(
    f"""
<style>
.appview-container .main .block-container{{
    {max_width_str}
}}
</style>
""",
    unsafe_allow_html=True,
)


st.sidebar.success("This Is V1.0.0")

# Create an instance of the app 
app = MultiPage()

app.add_page("FNO Analyser", fno_data_analyser.app)
app.add_page("MF Tracker", mfTracker.app)
app.add_page("Investing.com", investing_intraday_selection.app)
app.add_page("Stock Tracker", stockTracker.app)

app.add_page("Overall Analysis", dailyReportAnalysis.app)
app.add_page("Stock Analysis", ABuySellStock.app)
app.add_page("Pattern Scanner", PatternScanner.app)
    

# https://www.nseindia.com/api/quote-derivative?symbol=NIFTY

if __name__ == '__main__':
    app.run()